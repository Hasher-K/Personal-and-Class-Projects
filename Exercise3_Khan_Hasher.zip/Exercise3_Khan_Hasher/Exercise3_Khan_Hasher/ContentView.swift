//
//  ContentView.swift
//  Exercise2_Khan_Hasher
//
//  Created by Hasher Khan on 9/2/24.
//

import SwiftUI

struct ContentView: View {
    
    @State private var phoneGen = ["Image1", "Image2", "Image3"]
    @State private var phoneVers = ["iPhone 6", "iPhone 12", "iPhone 16"]
    
    @State private var phoneFeatures = [
        [
            "Release Date: 2014",
            "Design: Aluminum body, larger 4.7-inch or 5.5-inch display",
            "Processor: A8 chip",
            "Camera: 8MP rear-facing camera",
            "Storage: 16GB, 64GB, or 128GB",
            "Battery: 1810mAh (4.7-inch) or 2915mAh (5.5-inch)",
            "Notable Features: Touch ID fingerprint sensor, Apple Pay"
        ],
        [
            "Release Date: 2020",
            "Design: Flat edges, ceramic shield front, glass back",
            "Processor: A14 Bionic chip",
            "Camera: Dual 12MP rear-facing cameras",
            "Storage: 64GB, 128GB, or 256GB",
            "Battery: 2815mAh (6.1-inch) or 2775mAh (5.4-inch)",
            "Notable Features: 5G connectivity, MagSafe wireless charging, OLED display"
        ],
        [
            "Release Date: 2024",
            "Design: Similar to iPhone 15, but with potential design refinements",
            "Processor: A17 Bionic chip",
            "Camera: Improved camera system with potentially larger sensor and better low-light performance",
            "Storage: Likely to start at 128GB",
            "Battery: Expected to have improved battery life",
            "Notable Features: Advanced iOS features, potential new color options"
        ]
    ]
    
    @State private var phoneIdx = 0
    @State private var showingActionSheet = false
    @State private var isPhoneEditSheetPrsnt: Bool = false
    @State private var PhonetoEdit: String = ""
    
    var body: some View {
        VStack {
            Spacer()
            Text("iPhone Explorer")
                .font(.system(size: 30))
                .fontWeight(.bold)
                .foregroundColor(.myColor4)
                .shadow(radius: 10)
            
            Image(String(phoneGen[phoneIdx]))
                .resizable()
                .frame(width: 130, height: 130)
                .shadow(radius: 10, x: 10, y: 10)
                .padding()
            Spacer()
        }
        
        ScrollView {
            VStack {
                Text(String(phoneVers[phoneIdx]))
                    .padding(10)
                    .font(.system(size: 20))
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity)
                    .background(.myColor3)
                    .foregroundColor(.white)
            }
            
            VStack(alignment: .leading) {
                Spacer()
                
                ForEach(phoneFeatures[phoneIdx], id: \.self) { feature in
                    Text(Image(systemName: "apple.logo")) + Text(" \(feature)")
                        
                }
                .padding(1)
                
                Spacer()
            }
            .frame(maxWidth: .infinity)
            .background(.myColor1)
        }
        .padding()
        
        VStack {
            Button(action: {
                showNextPhone()
            }) {
                Text("Next phone")
                    .font(.system(size: 25).bold())
                    .fontWeight(.bold)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(.myColor2)
                    .foregroundColor(.white)
            }
            
            Button(action: {
                showingActionSheet = true
            }) {
                Text("Phone Selector")
                    .font(.system(size: 25).bold())
                    .fontWeight(.bold)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(.myColor2)
                    .foregroundColor(.white)
            }
            .confirmationDialog(
                "Pick a phone",
                isPresented: $showingActionSheet,
                titleVisibility: .visible
            ) {
                Button("iPhone 6") {
                    phoneIdx = 0
                }
                Button("iPhone 12") {
                    phoneIdx = 1
                }
                Button("iPhone 16") {
                    phoneIdx = 2
                }
                Button("Cancel", role: .cancel) {}
            }
            
            Button(action: {
                PhonetoEdit = phoneVers[phoneIdx]
                isPhoneEditSheetPrsnt = true
            }) {
                Text("Add new bullet")
                    .font(.system(size: 25).bold())
                    .fontWeight(.bold)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(.myColor3)
                    .foregroundColor(.white)
            }
            .sheet(isPresented: $isPhoneEditSheetPrsnt) {
                AddPhoneView(phoneVers: $phoneVers[phoneIdx], onSave: { newBullet in
                    let formattedBullet = " \(newBullet)"
                    phoneFeatures[phoneIdx].append(formattedBullet)
                })
            }
        }
        .padding()
    }
    
    func showNextPhone() {
        phoneIdx = (phoneIdx + 1) % phoneGen.count
    }
    
    func showRandPhone() {
        phoneIdx = Int.random(in: 0...2)
    }
}

#Preview {
    ContentView()
}
