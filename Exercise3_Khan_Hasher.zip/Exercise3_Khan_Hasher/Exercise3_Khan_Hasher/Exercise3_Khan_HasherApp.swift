//
//  Exercise3_Khan_HasherApp.swift
//  Exercise3_Khan_Hasher
//
//  Created by Hasher Khan on 9/9/24.
//

import SwiftUI

@main
struct Exercise3_Khan_HasherApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView(isActive: false)
        }
    }
}
