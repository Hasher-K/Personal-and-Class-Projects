//
//  AddPhoneView.swift
//  Exercise3_Khan_Hasher
//
//  Created by Hasher Khan on 9/9/24.
//

import SwiftUI

struct AddPhoneView: View {
    
    @Environment(\.presentationMode) var presentationMode
    @Binding var phoneVers: String
    @State private var newBullet: String = ""
    @State private var showEmptyAlert = false
    
    var onSave: (String) -> Void
    
    var body: some View {
        VStack {
            HStack {
                Button(action: {
                    print("Cancel")
                    presentationMode.wrappedValue.dismiss()
                }, label: {
                    Text("Cancel")
                })
                
                Spacer()
                
                Button(action: {
                    if newBullet.isEmpty {
                        showEmptyAlert = true
                    } else {
                        print("Done")
                        onSave(newBullet)
                        presentationMode.wrappedValue.dismiss()
                    }
                }, label: {
                    Text("Done")
                })
            }
            .padding()
            
            Text("ADD BULLET")
                .font(.system(size: 30))
                .fontWeight(.bold)
                .foregroundColor(.myColor4)
                .shadow(radius: 10)
            
            ScrollView {
                VStack {
                    Text("\(phoneVers)")
                        .padding(10)
                        .font(.system(size: 20))
                        .fontWeight(.bold)
                        .frame(maxWidth: 325)
                        .background(.myColor5)
                        .foregroundColor(.white)
                }
                
                VStack {}
                
                HStack {
                    Spacer(minLength: 67)
                    TextField("\(Image(systemName: "apple.logo")) New Bullet Point", text: $newBullet)
                    Spacer()
                }
                .padding(15)
                .font(.system(size: 16))
                .fontWeight(.bold)
                .frame(maxWidth: 325)
                .background(.myColor1)
                .foregroundColor(.black)
            }
            .padding()
            
            Spacer()
        }
        .alert(isPresented: $showEmptyAlert) {
            Alert(
                title: Text("Error"),
                message: Text("Bullet point cannot be empty."),
                dismissButton: .default(Text("Okay"))
            )
        }
    }
}

#Preview {
    AddPhoneView(phoneVers: .constant("iPhone 12"), onSave: { newBullet in
        print("Bullet saved: \(newBullet)")
    })
}
