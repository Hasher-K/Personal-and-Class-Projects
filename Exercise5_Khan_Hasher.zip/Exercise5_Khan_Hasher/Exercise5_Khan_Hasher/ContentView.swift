//
//  ContentView.swift
//  Exercise5_Khan_Hasher
//
//  Created by Hasher Khan on 10/4/24.
//

import SwiftUI

struct TransactionResponse: Codable {
    var transactions: [TransactionDate]
}

struct TransactionDate: Codable, Identifiable {
    var id = UUID()
    var date: String
    var entries: [TransactionEntry]

    private enum CodingKeys: String, CodingKey {
        case date, entries
    }
}

struct TransactionEntry: Codable, Identifiable {
    var id = UUID()
    var logo: String
    var title: String
    var amount: String
    var type: String
    var description: String
    var merchant_type: String
    var method: String
    var address: String
    var phone: String
    
    private enum CodingKeys: String, CodingKey {
        case logo, title, amount, type, description, merchant_type, method, address, phone
    }
}

// Main ContentView
struct ContentView: View {
    @State private var transactions = [TransactionDate]()
    @State private var searchText = ""
    @Environment(\.verticalSizeClass) var verticalSizeClass: UserInterfaceSizeClass?
    
    var filteredTransactions: [TransactionDate] {
        if searchText.isEmpty {
            return transactions
        } else {
            return transactions.map { transactionDate in
                let filteredEntries = transactionDate.entries.filter { $0.title.localizedCaseInsensitiveContains(searchText) }
                return TransactionDate(date: transactionDate.date, entries: filteredEntries)
            }.filter { !$0.entries.isEmpty }
        }
    }

    var body: some View {
        NavigationView {
            if verticalSizeClass == .regular {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Transactions")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding()

                    // Search bar
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                        TextField("Search", text: $searchText)
                            .padding(10)
                    }
                    .background(Color.myColor2)
                    .cornerRadius(8)
                    .padding(.horizontal)

                    List {
                        ForEach(filteredTransactions) { transactionDate in
                            Section(header: Text(transactionDate.date).font(.headline)) {
                                ForEach(transactionDate.entries) { entry in
                                    NavigationLink(destination: DetailView(entry: entry, date: transactionDate.date)) {
                                        HStack {
                                            AsyncImage(url: URL(string: entry.logo)) { image in
                                                image.resizable()
                                            } placeholder: {
                                                Image(systemName: "photo")
                                            }
                                            .frame(width: 50, height: 50)
                                            .clipShape(Circle())

                                            Text(entry.title)
                                                .font(.subheadline)
                                                .fontWeight(.bold)

                                            Spacer()

                                            Text(entry.amount)
                                                .font(.subheadline)
                                                .foregroundColor(.blue)
                                        }
                                    }
                                }
                                .padding(.top)
                                .padding(.bottom)
                            }
                        }
                    }
                    .task {
                        await loadData()
                    }
                    
                }
                .background(Color.myColor1)

            } else if verticalSizeClass == .compact {
                VStack() {
                    Text("Transactions")
                      
                        .fontWeight(.bold)
                        .padding()

                    // Search bar
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                        TextField("Search", text: $searchText)
                            .padding(10)
                    }
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                    .padding(.horizontal)

                    List {
                        ForEach(filteredTransactions) { transactionDate in
                            Section(header: Text(transactionDate.date).font(.headline)) {
                                ForEach(transactionDate.entries) { entry in
                                    NavigationLink(destination: DetailView(entry: entry, date: transactionDate.date)) {
                                        HStack {
                                            AsyncImage(url: URL(string: entry.logo)) { image in
                                                image.resizable()
                                            } placeholder: {
                                                Image(systemName: "photo")
                                            }
                                            .frame(width: 50, height: 50)
                                            .clipShape(Circle())

                                            Text(entry.title)
                                                .font(.subheadline)
                                                .fontWeight(.bold)

                                            Spacer()

                                            Text(entry.amount)
                                                .font(.subheadline)
                                                .foregroundColor(.blue)
                                        }
                                    }
                                }
                                .padding(.top)
                                .padding(.bottom)
                            }
                        }
                    }
                    .task {
                        await loadData()
                    }
                }
            }
        }
    }


    func loadData() async {
        guard let url = URL(string: "https://m.cpl.uh.edu/courses/ubicomp/fall2022/webservice/transactions/transactions.json") else {
            print("Invalid URL")
            return
        }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let decodedResponse = try JSONDecoder().decode(TransactionResponse.self, from: data)
            DispatchQueue.main.async {
                self.transactions = decodedResponse.transactions
            }
        } catch {
            print("Error decoding data: \(error)")
        }
    }
}



struct DetailView: View {
    @Environment(\.verticalSizeClass) var verticalSizeClass: UserInterfaceSizeClass?
    @Environment(\.presentationMode) var presentationMode
    
    var entry: TransactionEntry
    var date: String

    var body: some View {
        if verticalSizeClass == .regular {
            VStack(alignment: .leading, spacing: 10) {
                HStack{
                    AsyncImage(url: URL(string: entry.logo)) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 60, height: 60)
                    } placeholder: {
                        ProgressView()
                    }
                    
                    VStack(alignment: .leading, spacing: 10){
                        Text(entry.title)
                            .font(.title)
                            
                        Text(entry.merchant_type)
                            .foregroundStyle(Color.gray)
                    }
                    
                    Spacer()
                }
                
                Divider()

                Text("Date: \(date)")
                    .font(.headline)

                Text("Amount: \(entry.amount)")
                    .font(.headline)
                
                Text("Type: \(entry.type)")
                Text("Description: \(entry.description)")
                Text("Method: \(entry.method)")
                Text("Address: \(entry.address)")
                Text("Phone: \(entry.phone)")
                

                Spacer()
            }
            .padding()
            .navigationTitle("Transaction Details")
            .navigationBarBackButtonHidden(true)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        HStack {
                            Image(systemName: "chevron.left")
                            Text("Back")
                        }
                    }
                }
            }
        } else if verticalSizeClass == .compact {
            VStack(alignment: .leading, spacing: 10) {
                HStack{
                    AsyncImage(url: URL(string: entry.logo)) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 60, height: 60)
                    } placeholder: {
                        ProgressView()
                    }
                    
                    VStack(alignment: .leading, spacing: 10){
                        Text(entry.title)
                            .font(.title)
                            
                        Text(entry.merchant_type)
                            .foregroundStyle(Color.gray)
                    }
                    
                    Spacer()
                }
                
                Divider()

                Text("Date: \(date)")
                    .font(.headline)

                Text("Amount: \(entry.amount)")
                    .font(.headline)
                
                Text("Type: \(entry.type)")
                Text("Description: \(entry.description)")
                Text("Method: \(entry.method)")
                Text("Address: \(entry.address)")
                Text("Phone: \(entry.phone)")

                Spacer()
            }
            .padding()
            .navigationTitle("Transaction Details")
            .navigationBarBackButtonHidden(true)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        HStack {
                            Image(systemName: "chevron.left")
                            Text("Transactions")
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
