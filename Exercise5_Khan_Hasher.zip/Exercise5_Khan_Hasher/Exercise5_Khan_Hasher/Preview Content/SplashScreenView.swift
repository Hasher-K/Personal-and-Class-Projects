//
//  SplashScreenView.swift
//  Exercise5_Khan_Hasher
//
//  Created by Hasher Khan on 10/7/24.
//

import Foundation

import SwiftUI

struct SplashScreenView: View {
    @State var isActive : Bool = false
    @State private var size = 0.8
    @State private var opacity = 0.5
    
    var body: some View{
        if isActive{
            ContentView()
        } else {
            VStack {
                Spacer()
                Text("""
                    Hi, UbiComp F2024!
                    """
                ).font(.largeTitle)
                Spacer()
                
                Image(systemName: "banknote")
                    .resizable()
                    .frame(width: 375, height: 175)
                    .padding(13)
                Spacer()
                Spacer()
            }
            .onAppear{
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                    withAnimation {
                        self.isActive = true
                    }
                }
            }
        }
    }
}

#Preview {
    SplashScreenView()
}
