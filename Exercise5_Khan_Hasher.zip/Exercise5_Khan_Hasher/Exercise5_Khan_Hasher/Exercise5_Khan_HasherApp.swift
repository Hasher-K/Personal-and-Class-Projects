//
//  Exercise5_Khan_HasherApp.swift
//  Exercise5_Khan_Hasher
//
//  Created by Hasher Khan on 10/4/24.
//

import SwiftUI

@main
struct Exercise5_Khan_HasherApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView(isActive: false)
        }
    }
}
