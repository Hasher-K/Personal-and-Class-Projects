//
//  TaskerApp.swift
//  Tasker
//
//  Created by Hasher Khan on 12/4/24.
//

import SwiftUI

@main
struct TaskerApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView()
        }
    }
}
