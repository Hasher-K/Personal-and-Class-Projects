//
//  Exam2_Khan_HasherApp.swift
//  Exam2_Khan_Hasher
//
//  Created by Hasher Khan on 10/17/24.
//

import SwiftUI

@main
struct Exam2_Khan_HasherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
