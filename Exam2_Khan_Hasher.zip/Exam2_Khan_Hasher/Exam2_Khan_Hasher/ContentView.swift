//
//  ContentView.swift
//  Exam2_Khan_Hasher
//
//  Created by Hasher Khan on 10/17/24.
//

import SwiftUI

struct DogBreedsResponse: Codable {
    var message: [String: [String]]
    var status: String
}

struct ContentView: View {
    @State private var selectedTab = 0
    @State private var dogBreeds = [String]()
    @State private var searchText = ""
    @State private var favorites = Set<String>()

    var body: some View {
        TabView(selection: $selectedTab) {
            HomeView(dogBreeds: $dogBreeds, searchText: $searchText, favorites: $favorites)
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
                .tag(0)

            FavoritesView(favorites: $favorites)
                .tabItem {
                    Image(systemName: "star.fill")
                    Text("Favorites")
                }
                .tag(1)
        }
        .task {
            await loadDogBreeds()
        }
    }

    func loadDogBreeds() async {
        guard let url = URL(string: "https://dog.ceo/api/breeds/list/all") else {
            print("Invalid URL")
            return
        }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let decodedResponse = try JSONDecoder().decode(DogBreedsResponse.self, from: data)
            DispatchQueue.main.async {
                self.dogBreeds = Array(decodedResponse.message.keys).sorted()
            }
        } catch {
            print("Error decoding data: \(error)")
        }
    }
}

struct HomeView: View {
    @Binding var dogBreeds: [String]
    @Binding var searchText: String
    @Binding var favorites: Set<String>

    var filteredBreeds: [String] {
        if searchText.isEmpty {
            return dogBreeds
        } else {
            return dogBreeds.filter { $0.localizedCaseInsensitiveContains(searchText) }
        }
    }

    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 10) {
                Text("Dog Breeds")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()

                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.gray)
                    TextField("Search", text: $searchText)
                        .padding(10)
                }
                .background(Color(.systemGray6))
                .cornerRadius(8)
                .padding(.horizontal)

                List {
                    ForEach(filteredBreeds, id: \.self) { breed in
                        NavigationLink(destination: DogBreedDetailView(breed: breed, favorites: $favorites)) {
                            HStack {
                                Text(breed.capitalized)
                                    .padding(.vertical, 10)
                                Spacer()
                                Button(action: {
                                    toggleFavorite(breed: breed)
                                }) {
                                    Image(systemName: favorites.contains(breed) ? "star.fill" : "star")
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                            .padding()
                            .background(Color(.systemGray5))
                            .cornerRadius(10)
                        }
                        .listRowSeparator(.hidden)
                    }
                }
                
                .listStyle(PlainListStyle())
            }
            .navigationViewStyle(StackNavigationViewStyle())
        }
        
        .navigationViewStyle(StackNavigationViewStyle())
        
    }
    

    private func toggleFavorite(breed: String) {
        if favorites.contains(breed) {
            favorites.remove(breed)
        } else {
            favorites.insert(breed)
        }
    }
}

struct FavoritesView: View {
    @Binding var favorites: Set<String>

    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 10) {
                Text("Favorite Breeds")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()

                if favorites.isEmpty {
                    Text("No favorite breeds yet.")
                        .font(.subheadline)
                        .padding()
                } else {
                    List {
                        ForEach(Array(favorites), id: \.self) { breed in
                            NavigationLink(destination: DogBreedDetailView(breed: breed, favorites: $favorites)) {
                                HStack {
                                    Text(breed.capitalized)
                                        .padding(.vertical, 10)
                                    Spacer()
                                    Image(systemName: "star.fill")
                                }
                                .padding()
                                .background(Color(.systemGray5))
                                .cornerRadius(10)
                            }
                        }
                    }
                    .listStyle(PlainListStyle())
                }
            }
            .navigationViewStyle(StackNavigationViewStyle())
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}


struct DogBreedDetailView: View {
    var breed: String
    @Binding var favorites: Set<String>
    @State private var breedImages = [String]()
    @Environment(\.verticalSizeClass) var verticalSizeClass: UserInterfaceSizeClass?
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        if verticalSizeClass == .regular {
            VStack {
                HStack {
                    Text(breed.capitalized)
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    
                    
                    
                    Button(action: {
                        toggleFavorite()
                    }) {
                        Image(systemName: favorites.contains(breed) ? "star.fill" : "star")
                            .foregroundColor(favorites.contains(breed) ? .black : .black)
                    }
                }
                .padding()
                
                if breedImages.isEmpty {
                    Text("No images available")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .padding()
                } else {
                    TabView {
                        ForEach(breedImages, id: \.self) { imageUrl in
                            AsyncImage(url: URL(string: imageUrl)) { image in
                                image.resizable()
                                    .scaledToFit()
                                    .frame(height: 300)
                                    .cornerRadius(10)
                                    .padding()
                            } placeholder: {
                                ProgressView()
                            }
                        }
                    }
                    .tabViewStyle(PageTabViewStyle())
                    .frame(height: 300)
                }
                
                Text("No description available")
                    .foregroundColor(Color(.systemGray2))
                
                Spacer()
            }
            .onAppear {
                Task {
                    await loadBreedImages()
                }
            }
            .navigationBarBackButtonHidden(true)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        HStack {
                            Image(systemName: "chevron.left")
                            Text("Dog Breeds")
                        }
                    }
                }
            }
        }else if verticalSizeClass == .compact{
            VStack {
                HStack {
                    Text(breed.capitalized)
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    
                    
                    
                    Button(action: {
                        toggleFavorite()
                    }) {
                        Image(systemName: favorites.contains(breed) ? "star.fill" : "star")
                            .foregroundColor(favorites.contains(breed) ? .black : .black)
                    }
                }
                .padding()
                
                if breedImages.isEmpty {
                    Text("No images available")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .padding()
                } else {
                    TabView {
                        ForEach(breedImages, id: \.self) { imageUrl in
                            AsyncImage(url: URL(string: imageUrl)) { image in
                                image.resizable()
                                    .scaledToFit()
                                    .frame(height: 150)
                                    .cornerRadius(10)
                                   
                            } placeholder: {
                                ProgressView()
                            }
                        }
                    }
                    .tabViewStyle(PageTabViewStyle())
                    .frame(height: 300)
                }
                
            
                
                Spacer()
                Spacer()
            }
            .onAppear {
                Task {
                    await loadBreedImages()
                }
            }
            .navigationBarBackButtonHidden(true)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        HStack {
                            Image(systemName: "chevron.left")
                            Text("Dog Breeds")
                        }
                    }
                }
            }
        }
        
    }

    private func toggleFavorite() {
        if favorites.contains(breed) {
            favorites.remove(breed)
        } else {
            favorites.insert(breed)
        }
    }

    func loadBreedImages() async {
        let breedLowercased = breed.lowercased()
        let breedName = breedLowercased.replacingOccurrences(of: " ", with: "/")
        guard let url = URL(string: "https://dog.ceo/api/breed/\(breedName)/images") else {
            print("Invalid URL")
            return
        }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let decodedResponse = try JSONDecoder().decode(DogBreedImagesResponse.self, from: data)
            DispatchQueue.main.async {
                self.breedImages = decodedResponse.message
            }
        } catch {
            print("Error fetching images: \(error)")
        }
    }
}

struct DogBreedImagesResponse: Codable {
    var message: [String]
    var status: String
}

#Preview {
    ContentView()
}
