//
//  Exercise2_Khan_HasherApp.swift
//  Exercise2_Khan_Hasher
//
//  Created by Hasher Khan on 9/2/24.
//

import SwiftUI

@main
struct Exercise2_Khan_HasherApp: App {
    var body: some Scene {
        WindowGroup {
           // ContentView()
            SplashScreenView(isActive: false)
        }
    }
}
