//
//  ContentView.swift
//  Exercise2_Khan_Hasher
//
//  Created by Hasher Khan on 9/2/24.
//

import SwiftUI

struct ContentView: View {
    
    @State private var phoneGen = ["Image1", "Image2", "Image3"]
    @State private var phoneVers = ["iPhone 6", "iPhone 12", "iPhone 16"]
    @State private var phoneRelease = ["in 2014", "2020", "2024"]
    @State private var phoneDesign = ["Aluminum body, larger 4.7-inch or 5.5-inch display", "Flat edges, ceramic shield front, glass back", "Similar to iPhone 15, but with potential design refinements"]
    @State private var phoneProcessor = ["A8 chip", "A14 Bionic chip", "A17 Bionic chip"]
    @State private var phoneCamera = ["8MP rear-facing camera", "Dual 12MP rear-facing cameras", "Improved camera system with potentially larger sensor and better low-light performance"]
    @State private var phoneStorage = ["16GB, 64GB, or 128GB", "64GB, 128GB, or 256GB", "Likely to start at 128GB"]
    @State private var phoneBattery = ["1810mAh (4.7-inch) or 2915mAh (5.5-inch)", "2815mAh (6.1-inch) or 2775mAh (5.4-inch)", "Expected to have improved battery life"]
    @State private var phoneFeatures = ["Touch ID fingerprint sensor, Apple Pay", "5G connectivity, MagSafe wireless charging, OLED display", "Advanced iOS features, potential new color options"]
    @State private var phoneIdx = 0
    
    @State private var showingActionSheet = false
    
    var body: some View {
        VStack {
            Spacer()
            Text("iPhone Explorer")
                .font(.system(size: 30))
                .fontWeight(.bold)
                .foregroundColor(.myColor4)
                .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
            
            Image(String(phoneGen[phoneIdx]))
                .resizable()
                .frame(width: 130, height: 130)
                .shadow(radius: 10, x: 10, y: 10)
                .padding()
            Spacer()
            
        
     
            
            
            
        }
        
        ScrollView{
            VStack{
                Text(String(phoneVers[phoneIdx]))
                    .padding(10)
                    .font(.system(size: 20))
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity)
                    .background(.myColor3)
                    .foregroundColor(.white)
            }
            VStack (alignment: .leading){
                Spacer()
                Text(Image(systemName: "apple.logo")) + Text(" Release Date: " + String(phoneRelease[phoneIdx]))
                Spacer()
                
                Text(Image(systemName: "apple.logo")) + Text(" Design: " + String(phoneDesign[phoneIdx]))
                Spacer()
                
                Text(Image(systemName: "apple.logo")) + Text(" Processor: " + String(phoneProcessor[phoneIdx]))
                Spacer()
                
                Text(Image(systemName: "apple.logo")) + Text(" Camera: " + String(phoneCamera[phoneIdx]))
                Spacer()
                
                Text(Image(systemName: "apple.logo")) + Text(" Storage: " + String(phoneStorage[phoneIdx]))
                Spacer()
                
                Text(Image(systemName: "apple.logo")) + Text(" Battery: " + String(phoneBattery[phoneIdx]))
                Spacer()
                
                Text(Image(systemName: "apple.logo")) + Text(" Notable Features: " + String(phoneFeatures[phoneIdx]))
                Spacer()
                
    
            }
            
            
            .frame(maxWidth: .infinity)
            .background(.myColor1)
        
        }
        .padding()
        
        VStack{
            
            Button(action:{
                showRandPhone()
            }){
                Text("Random phone")
                    .font(.system(size: 25).bold())
                    .fontWeight(.bold)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(.myColor2)
                    .foregroundColor(.white)
            }
           
            
            Button(action:{
                showNextPhone()
            }){
                Text("Next phone")
                    .font(.system(size: 25).bold())
                    .fontWeight(.bold)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(.myColor2)
                    .foregroundColor(.white)
            }
         
            
            Button(action:{
                showingActionSheet = true
            }){
                Text("Phone Selector")
                    .font(.system(size: 25).bold())
                    .fontWeight(.bold)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(.myColor2)
                    .foregroundColor(.white)
            }
            .confirmationDialog(
                        "Pick a phone",
                        isPresented: $showingActionSheet,
                        titleVisibility: .visible
                    ) {
                        Button("iPhone 6") {
                            phoneIdx = 0
                        }
                        Button("iPhone 12") {
                            phoneIdx = 1
                        }
                        Button("iPhone 16") {
                            phoneIdx = 2
                        }
                        Button("Cancel", role: .cancel) {}
                    }
            
            
            
        }
    
        .padding()
    
    }
    
    func showNextPhone(){
        phoneIdx = (phoneIdx + 1) % phoneGen.count
        
    }
    
    func showRandPhone(){
        phoneIdx = Int.random(in: 0...2)
    }
    
  
        
}

#Preview {
    ContentView()
}
