//
//  ContentView.swift
//  Exercise6_Khan_Hasher
//
//  Created by Hasher Khan on 10/4/24.
//

import SwiftUI
import MapKit

struct TransactionResponse: Codable {
    var transactions: [TransactionDate]
}

struct TransactionDate: Codable, Identifiable {
    var id = UUID()
    var date: String
    var entries: [TransactionEntry]

    private enum CodingKeys: String, CodingKey {
        case date, entries
    }
}

struct TransactionEntry: Codable, Identifiable {
    var id = UUID()
    var logo: String
    var title: String
    var amount: String
    var type: String
    var description: String
    var merchant_type: String
    var method: String
    var address: String
    var phone: String
    var cap_lat: Double  // New field for latitude
    var cap_long: Double // New field for longitude

    private enum CodingKeys: String, CodingKey {
        case logo, title, amount, type, description, merchant_type, method, address, phone, cap_lat, cap_long
    }
}

// Main ContentView
struct ContentView: View {
    @State private var transactions = [TransactionDate]()
    @State private var searchText = ""
    @Environment(\.verticalSizeClass) var verticalSizeClass: UserInterfaceSizeClass?
    
    var filteredTransactions: [TransactionDate] {
        if searchText.isEmpty {
            return transactions
        } else {
            return transactions.map { transactionDate in
                let filteredEntries = transactionDate.entries.filter { $0.title.localizedCaseInsensitiveContains(searchText) }
                return TransactionDate(date: transactionDate.date, entries: filteredEntries)
            }.filter { !$0.entries.isEmpty }
        }
    }

    var body: some View {
        NavigationView {
            if verticalSizeClass == .regular {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Transactions")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding()

                    // Search bar
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                        TextField("Search", text: $searchText)
                            .padding(10)
                    }
                    .background(Color.myColor2)
                    .cornerRadius(8)
                    .padding(.horizontal)

                    List {
                        ForEach(filteredTransactions) { transactionDate in
                            Section(header: Text(transactionDate.date).font(.headline)) {
                                ForEach(transactionDate.entries) { entry in
                                    NavigationLink(destination: DetailView(entry: entry, date: transactionDate.date)) {
                                        HStack {
                                            AsyncImage(url: URL(string: entry.logo)) { image in
                                                image.resizable()
                                            } placeholder: {
                                                Image(systemName: "photo")
                                            }
                                            .frame(width: 50, height: 50)
                                            .clipShape(Circle())

                                            Text(entry.title)
                                                .font(.subheadline)
                                                .fontWeight(.bold)

                                            Spacer()

                                            Text(entry.amount)
                                                .font(.subheadline)
                                                .foregroundColor(.blue)
                                        }
                                    }
                                }
                                .padding(.top)
                                .padding(.bottom)
                            }
                        }
                    }
                    .task {
                        await loadData()
                    }
                    
                }
                .background(Color.myColor1)

            } else if verticalSizeClass == .compact {
                VStack() {
                    Text("Transactions")
                      
                        .fontWeight(.bold)
                        .padding()

                    // Search bar
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                        TextField("Search", text: $searchText)
                            .padding(10)
                    }
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                    .padding(.horizontal)

                    List {
                        ForEach(filteredTransactions) { transactionDate in
                            Section(header: Text(transactionDate.date).font(.headline)) {
                                ForEach(transactionDate.entries) { entry in
                                    NavigationLink(destination: DetailView(entry: entry, date: transactionDate.date)) {
                                        HStack {
                                            AsyncImage(url: URL(string: entry.logo)) { image in
                                                image.resizable()
                                            } placeholder: {
                                                Image(systemName: "photo")
                                            }
                                            .frame(width: 50, height: 50)
                                            .clipShape(Circle())

                                            Text(entry.title)
                                                .font(.subheadline)
                                                .fontWeight(.bold)

                                            Spacer()

                                            Text(entry.amount)
                                                .font(.subheadline)
                                                .foregroundColor(.blue)
                                        }
                                    }
                                }
                                .padding(.top)
                                .padding(.bottom)
                            }
                        }
                    }
                    .task {
                        await loadData()
                    }
                }
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }


    func loadData() async {
        guard let url = URL(string: "https://m.cpl.uh.edu/courses/ubicomp/fall2022/webservice/transactions/transactions_map.json") else {
            print("Invalid URL")
            return
        }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let decodedResponse = try JSONDecoder().decode(TransactionResponse.self, from: data)
            DispatchQueue.main.async {
                self.transactions = decodedResponse.transactions
            }
        } catch {
            print("Error decoding data: \(error)")
        }
    }
}






struct DetailView: View {
    @Environment(\.verticalSizeClass) var verticalSizeClass: UserInterfaceSizeClass?
    @Environment(\.presentationMode) var presentationMode
    
    var entry: TransactionEntry
    var date: String
    
    @State private var region: MKCoordinateRegion
    
    init(entry: TransactionEntry, date: String) {
        self.entry = entry
        self.date = date
        
        // Initialize the region based on entry's coordinates
        _region = State(initialValue: MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: entry.cap_lat, longitude: entry.cap_long),
            span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        ))
    }

    var body: some View {
        if verticalSizeClass == .regular {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    AsyncImage(url: URL(string: entry.logo)) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 60, height: 60)
                    } placeholder: {
                        ProgressView()
                    }
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text(entry.title)
                            .font(.title)
                            
                        Text(entry.merchant_type)
                            .foregroundColor(.gray)
                    }
                    
                    Spacer()
                }
                
                Divider()

                Text("Date: \(date)")
                    .font(.headline)

                Text("Amount: \(entry.amount)")
                    .font(.headline)
                
                Text("Type: \(entry.type)")
                Text("Description: \(entry.description)")
                Text("Method: \(entry.method)")
                Text("Address: \(entry.address)")
                Text("Phone: \(entry.phone)")
                
                // Add the MapView for displaying the transaction location using the coordinates
                MapView(latitude: entry.cap_lat, longitude: entry.cap_long, address: entry.address, region: $region)
                    .frame(height: 300)
                    .cornerRadius(10)
                    .padding(.top)

                Spacer()
            }
            .padding()
            .navigationTitle("Transaction Details")
            .navigationBarBackButtonHidden(true)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        HStack {
                            Image(systemName: "chevron.left")
                            Text("Back")
                        }
                    }
                }
            }
        } else if verticalSizeClass == .compact {
            HStack {
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        AsyncImage(url: URL(string: entry.logo)) { image in
                            image
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 60, height: 60)
                        } placeholder: {
                            ProgressView()
                        }
                        
                        VStack(alignment: .leading, spacing: 10) {
                            Text(entry.title)
                                .font(.title)
                                
                            Text(entry.merchant_type)
                                .foregroundColor(.gray)
                        }
                        
                        Spacer()
                    }
                    
                    Divider()

                    Text("Date: \(date)")
                        .font(.headline)

                    Text("Amount: \(entry.amount)")
                        .font(.headline)
                    
                    Text("Type: \(entry.type)")
                    Text("Description: \(entry.description)")
                    Text("Method: \(entry.method)")
                    Text("Address: \(entry.address)")
                    Text("Phone: \(entry.phone)")
                    
                    // Add the MapView for compact size classes as well
                    
                }
                .padding()
                .navigationTitle("Transaction Details")
                .navigationBarBackButtonHidden(true)
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss()
                        }) {
                            HStack {
                                Image(systemName: "chevron.left")
                                Text("Transactions")
                            }
                        }
                    }
                }
                VStack{
                    MapView(latitude: entry.cap_lat, longitude: entry.cap_long, address: entry.address, region: $region)
                        .frame(height: 300)
                        .cornerRadius(10)
                        .padding(.top)

                    Spacer()
                }
            }
        }
    }
}


#Preview {
    ContentView()
}
