//
//  Exercise6_Khan_HasherApp.swift
//  Exercise6_Khan_Hasher
//
//  Created by Hasher Khan on 10/10/24.
//

import SwiftUI

@main
struct Exercise6_Khan_HasherApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView(isActive: false)
        }
    }
}
