//
//  MapView.swift
//  Exercise6_Khan_Hasher
//
//  Created by Hasher Khan on 10/10/24.
//

import SwiftUI
import MapKit

struct MapView: UIViewRepresentable {
    var latitude: Double
    var longitude: Double
    var address: String
    @Binding var region: MKCoordinateRegion
    @State private var annotation = MKPointAnnotation()
    
    // To track the unique pin number for long press gestures
    @State private var pinNumber = 0

    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        
        // Long press gesture to add custom pins
        let longPressGesture = UILongPressGestureRecognizer(target: context.coordinator, action: #selector(context.coordinator.addPin(gestureRecognizer:)))
        longPressGesture.minimumPressDuration = 2.0 // 2-second long press
        mapView.addGestureRecognizer(longPressGesture)
        
        mapView.setRegion(region, animated: true)
        mapView.addAnnotation(annotation)
        
        return mapView
    }

    func updateUIView(_ uiView: MKMapView, context: Context) {
        let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        region.center = coordinate
        annotation.coordinate = coordinate
        annotation.title = address
        uiView.setRegion(region, animated: true)
        if !uiView.annotations.contains(where: { $0.coordinate.latitude == annotation.coordinate.latitude && $0.coordinate.longitude == annotation.coordinate.longitude }) {
            uiView.addAnnotation(annotation)
        }
    }
    
    // Coordinator for handling delegate methods and gestures
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, MKMapViewDelegate {
        var parent: MapView
        var pinCount = 0
        
        init(_ parent: MapView) {
            self.parent = parent
        }
        
        // MKMapViewDelegate method to handle pin selection (tapping on the pin)
        func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
            guard let annotation = view.annotation else { return }
            
            // Reverse geocoding to highlight administrative area, locality, and ISO country code
            let location = CLLocation(latitude: annotation.coordinate.latitude, longitude: annotation.coordinate.longitude)
            let geocoder = CLGeocoder()
            geocoder.reverseGeocodeLocation(location) { (placemarks, error) in
                if let placemark = placemarks?.first {
                    let administrativeArea = placemark.administrativeArea ?? "N/A"
                    let locality = placemark.locality ?? "N/A"
                    let isoCountryCode = placemark.isoCountryCode ?? "N/A"
                    
                    // Display the details in the annotation's subtitle
                    //annotation.subtitle = "Area: \(administrativeArea), Locality: \(locality), Country: \(isoCountryCode)"
                }
            }
        }
        
        // Method to handle long press gesture and add a custom pin
        @objc func addPin(gestureRecognizer: UILongPressGestureRecognizer) {
            guard let mapView = gestureRecognizer.view as? MKMapView else { return }
            
            if gestureRecognizer.state == .began {
                let touchPoint = gestureRecognizer.location(in: mapView)
                let coordinate = mapView.convert(touchPoint, toCoordinateFrom: mapView)
                
                // Add a new pin with a unique number and custom subtitle
                pinCount += 1
                let newAnnotation = MKPointAnnotation()
                newAnnotation.coordinate = coordinate
                newAnnotation.title = "Custom Pin #\(pinCount)"
                newAnnotation.subtitle = "This is pin number \(pinCount)"
                
                mapView.addAnnotation(newAnnotation)
            }
        }
    }
}
