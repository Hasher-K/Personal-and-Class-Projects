//
//  Exercise4_Khan_HasherApp.swift
//  Exercise4_Khan_Hasher
//
//  Created by Hasher Khan on 9/16/24.
//

import SwiftUI

@main
struct Exercise4_Khan_HasherApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView(isActive: false)
        }
    }
}
