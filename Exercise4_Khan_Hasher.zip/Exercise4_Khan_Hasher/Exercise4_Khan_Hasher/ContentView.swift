//
//  ContentView.swift
//  Exercise4_Khan_Hasher
//
//  Created by Hasher Khan on 9/16/24.
//

import SwiftUI

struct ContentView: View {
    @State private var isActive = false
    @State private var score_1 = 0
    @State private var score_2 = 0
    
    var body: some View {

        VStack {
            TabView{
                GameView()
                ScoreView()
                    .tabItem {
                        Image("score_off")
                        Text("Score")}
                
            }
                
        }
 
    }
}



#Preview {
    ContentView()
}
