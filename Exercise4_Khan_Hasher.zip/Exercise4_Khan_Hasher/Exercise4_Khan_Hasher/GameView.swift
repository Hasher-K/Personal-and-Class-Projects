//
//  GameView.swift
//  Exercise4_Khan_Hasher
//
//  Created by Hasher Khan on 9/17/24.
//

import SwiftUI

struct GameView: View {
    @State private var isActive = false
    @Environment(\.verticalSizeClass) var verticalSizeClass: UserInterfaceSizeClass?
    
    var body: some View {
        NavigationStack {
            
            if verticalSizeClass == .regular {
                VStack {
                    VStack{
                        Image("0_HOD_text")
                            .resizable()
                            .frame(width: 375, height: 55)
                            .padding(13)
                        
                        Spacer(minLength: 40)
                        
                        HStack{
                            Spacer()
                            Text("Player 1")
                                .font(.custom("AcademyEngravedLETPlain", size: 30))
                            
                            Spacer()
                            
                            Text("Player 2")
                                .font(.custom("AcademyEngravedLETPlain", size: 30))
                            Spacer()
                        }
                        
                        HStack{
                            Spacer()
                            Image("0_HOD_logo")
                                .resizable()
                                .frame(width: 150, height: 150)
                            Spacer()
                            
                            Image("0_HOD_logo")
                                .resizable()
                                .frame(width: 150, height: 150)
                            Spacer()
                        }
                        Spacer(minLength: 50)
                    }
                    VStack{
                        Text("Prepare for the battle!")
                                .font(.custom("AcademyEngravedLETPlain", size: 33))
                                .padding(4)
                        
                   
                        HStack{
                            Spacer()
                            Button(action: {
                                // Action to perform when button is tapped
                         
                                isActive = false
                             
                            }) {
                                VStack{
                                    Spacer()
                                    Text("Restart")
                                        .font(.custom("AcademyEngravedLETPlain", size: 30))
                                        .foregroundColor(.primary)
                                    Image("0_refresh_arrows")
                                        .resizable()
                                        .frame(width: 120, height: 120)
                                    
                                    
                                    
                                }
                            }
                            Spacer()
                            Button(action: {
                                // Action to perform when button is tapped
                                isActive = true
                            }) {
                                VStack{
                                    Spacer()
                                    Text("Fight")
                                        .font(.custom("AcademyEngravedLETPlain", size: 30))
                                        .foregroundColor(.primary)
                                    Image("0_crossing-swords")
                                        .resizable()
                                        .frame(width: 120, height: 120)
                                    
                                }
                            }
                            Spacer()
                        }
                        .navigationDestination(isPresented: $isActive) {
                            GameView_01()
                        }

                        Spacer(minLength: 20)
                        
                        
                        
                            HStack{
                                Spacer()
                                
                                
                                
                                
                        }
                    }
                }
            }else if verticalSizeClass == .compact{
                HStack {
                    VStack{
                        Image("0_HOD_text")
                            .resizable()
                            .frame(width: 375, height: 55)
                            .padding(13)
                        
                        Spacer(minLength: 40)
                        
                        HStack{
                            Spacer()
                            Text("Player 1")
                                .font(.custom("AcademyEngravedLETPlain", size: 30))
                            
                            Spacer()
                            
                            Text("Player 2")
                                .font(.custom("AcademyEngravedLETPlain", size: 30))
                            Spacer()
                        }
                        
                        HStack{
                            Spacer()
                            Image("0_HOD_logo")
                                .resizable()
                                .frame(width: 150, height: 150)
                            Spacer()
                            
                            Image("0_HOD_logo")
                                .resizable()
                                .frame(width: 150, height: 150)
                            Spacer()
                        }
                        Spacer(minLength: 50)
                    }
                    VStack{
                        Text("Prepare for the battle!")
                                .font(.custom("AcademyEngravedLETPlain", size: 33))
                                .padding(4)
                        
                   
                        HStack{
                            Spacer()
                            Button(action: {
                                // Action to perform when button is tapped
                         
                                isActive = false
                             
                            }) {
                                VStack{
                                    Spacer()
                                    Text("Restart")
                                        .font(.custom("AcademyEngravedLETPlain", size: 30))
                                        .foregroundColor(.primary)
                                    Image("0_refresh_arrows")
                                        .resizable()
                                        .frame(width: 120, height: 120)
                                    
                                    
                                    
                                }
                            }
                            Spacer()
                            Button(action: {
                                // Action to perform when button is tapped
                                isActive = true
                            }) {
                                VStack{
                                    Spacer()
                                    Text("Fight")
                                        .font(.custom("AcademyEngravedLETPlain", size: 30))
                                        .foregroundColor(.primary)
                                    Image("0_crossing-swords")
                                        .resizable()
                                        .frame(width: 120, height: 120)
                                    
                                }
                            }
                            Spacer()
                        }
                        .navigationDestination(isPresented: $isActive) {
                            GameView_01()
                        }

                        Spacer(minLength: 20)
                        
                        
                        
                            HStack{
                                Spacer()
                                
                                
                                
                                
                        }
                    }
                }
            }
            
        }
        .tabItem {
            Image("fire_off")
            Text("Fight")
            
        }
        .navigationBarBackButtonHidden(true)
        
       
    }
}

struct GameView_01: View {
    @Environment(\.verticalSizeClass) var verticalSizeClass: UserInterfaceSizeClass?

    
    @State private var isActive = false
    @State private var dragonlist = ["Balerion", "Sheepstealer", "Silverwing", "Meleys", "Quicksilver", "Stormcloud", "Drogon", "Viserion"]
    @State private var dragonIdx_1 = 0
    @State private var dragonIdx_2 = 0
    @State private var score_1 = 0
    @State private var score_2 = 0
    
    var body: some View {
        
        
        if verticalSizeClass == .regular {
            VStack {
                
                VStack{
                    Image("0_HOD_text")
                        .resizable()
                        .frame(width: 375, height: 55)
                    Spacer(minLength: 40)
                    
                    HStack{
                        Spacer()
                        Text("Player 1")
                            .font(.custom("AcademyEngravedLETPlain", size: 30))
                        
                        Spacer()
                        
                        Text("Player 2")
                            .font(.custom("AcademyEngravedLETPlain", size: 30))
                        Spacer()
                    }
                    
                    HStack{
                        Spacer()
                        Image(String(dragonlist[dragonIdx_1]))
                            .resizable()
                            .frame(width: 150, height: 150)
                        Spacer()
                        
                        Image(String(dragonlist[dragonIdx_2]))
                            .resizable()
                            .frame(width: 150, height: 150)
                        Spacer()
                    }
                    Spacer(minLength: 70)
                }
                
                VStack{
                    //Keep count of layer scores
                    if score_1 < 3 && score_2 < 3 {
                        
                        //Handle win messages
                        if dragonIdx_1 < dragonIdx_2{
                            
                            Text(String(dragonlist[dragonIdx_1])).font(.custom("AcademyEngravedLETPlain", size: 35))+Text(" is stronger.")
                                .font(.custom("AcademyEngravedLETPlain", size: 35))
                            Text("Player 1 wins the round!")
                                .font(.custom("AcademyEngravedLETPlain", size: 35))
                            
                        }else if dragonIdx_1 > dragonIdx_2{
                            Text(String(dragonlist[dragonIdx_1])).font(.custom("AcademyEngravedLETPlain", size: 35))+Text(" is stronger.")
                                .font(.custom("AcademyEngravedLETPlain", size: 35))
                            Text("Player 2 wins the round!")
                                .font(.custom("AcademyEngravedLETPlain", size: 35))
                        }else{
                            Text("Begin the round!")
                                .font(.custom("AcademyEngravedLETPlain", size: 35))
                        }
                    }else{
                        if score_1 == 3{
                            Text("Player 1 won (").font(.custom("AcademyEngravedLETPlain", size: 35)) + Text(String(score_1)).font(.custom("AcademyEngravedLETPlain", size: 35)) + Text(" - ").font(.custom("AcademyEngravedLETPlain", size: 35)) + Text(String(score_2)).font(.custom("AcademyEngravedLETPlain", size: 35)) + Text(")").font(.custom("AcademyEngravedLETPlain", size: 35))
                            
                            Text("Restart the game.")
                                .font(.custom("AcademyEngravedLETPlain", size: 35))
                        }
                        if score_2 == 3{
                            Text("Player 2 won (").font(.custom("AcademyEngravedLETPlain", size: 35)) + Text(String(score_1)).font(.custom("AcademyEngravedLETPlain", size: 35)) + Text(" - ").font(.custom("AcademyEngravedLETPlain", size: 35)) + Text(String(score_2)).font(.custom("AcademyEngravedLETPlain", size: 35)) + Text(")").font(.custom("AcademyEngravedLETPlain", size: 35))
                            
                            Text("Restart the game.")
                                .font(.custom("AcademyEngravedLETPlain", size: 35))
                        }
                    }
                    
                    Spacer()
                    
                    
                    HStack{
                        Spacer()
                        Button(action: {
                            // Action to perform when button is tapped
                            isActive = true
                            dragonIdx_1 = 0
                            dragonIdx_2 = 0
                            score_1 = 0
                            score_2 = 0
                        }) {
                            VStack{
                                Spacer()
                                Text("Restart")
                                    .font(.custom("AcademyEngravedLETPlain", size: 30))
                                    .foregroundColor(.primary)
                                Image("0_refresh_arrows")
                                    .resizable()
                                    .frame(width: 120, height: 120)
                                
                                
                                
                            }
                        }
                        Spacer()
                        Button(action: {
                            // Action to perform when button is tapped
                            randomIdx()
                            
                            if dragonIdx_1 < dragonIdx_2 {
                                score_1 = score_1 + 1
                            }
                            else if dragonIdx_1 > dragonIdx_2 {
                                score_2 = score_2 + 1
                            }
                        }) {
                            VStack{
                                Spacer()
                                Text("Fight")
                                    .font(.custom("AcademyEngravedLETPlain", size: 30))
                                    .foregroundColor(.primary)
                                Image("0_crossing-swords")
                                    .resizable()
                                    .frame(width: 120, height: 120)
                                
                            }
                        }
                        .disabled(score_1 == 3 || score_2 == 3)
                        Spacer()
                    }
                    .navigationDestination(isPresented: $isActive) {
                        GameView()
                    }
                    
                    Spacer()
                }
            }
            
            
            
            .tabItem {
                Image("fire_off")
                Text("Fight")
                
            }
        .navigationBarBackButtonHidden(true)
        }else if verticalSizeClass == .compact{
            HStack {
                
                VStack{
                    Image("0_HOD_text")
                        .resizable()
                        .frame(width: 375, height: 55)
                        .padding(15)
                    Spacer(minLength: 40)
                    
                    HStack{
                        Spacer()
                        Text("Player 1")
                            .font(.custom("AcademyEngravedLETPlain", size: 30))
                            
                        
                        Spacer()
                        
                        Text("Player 2")
                            .font(.custom("AcademyEngravedLETPlain", size: 30))
                        Spacer()
                    }
                    
                    HStack{
                        Spacer()
                        Image(String(dragonlist[dragonIdx_1]))
                            .resizable()
                            .frame(width: 150, height: 150)
                        Spacer()
                        
                        Image(String(dragonlist[dragonIdx_2]))
                            .resizable()
                            .frame(width: 150, height: 150)
                        Spacer()
                    }
                    Spacer(minLength: 70)
                }
                
                VStack{
                    //Keep count of layer scores
                    Spacer()
                    if score_1 < 3 && score_2 < 3 {
                        
                        //Handle win messages
                        if dragonIdx_1 < dragonIdx_2{
                            
                            Text(String(dragonlist[dragonIdx_1])).font(.custom("AcademyEngravedLETPlain", size: 35))+Text(" is stronger.")
                                .font(.custom("AcademyEngravedLETPlain", size: 34))
                                
                            Text("Player 1 wins the round!")
                                .font(.custom("AcademyEngravedLETPlain", size: 34))
                            
                        }else if dragonIdx_1 > dragonIdx_2{
                            Text(String(dragonlist[dragonIdx_1])).font(.custom("AcademyEngravedLETPlain", size: 35))+Text(" is stronger.")
                                .font(.custom("AcademyEngravedLETPlain", size: 34))
                            Text("Player 2 wins the round!")
                                .font(.custom("AcademyEngravedLETPlain", size: 34))
                            
                        }else{
                            Text("Begin the round!")
                                .font(.custom("AcademyEngravedLETPlain", size: 34))
                                .padding()
                        }
                    }else{
                        if score_1 == 3{
                            Text("Player 1 won (").font(.custom("AcademyEngravedLETPlain", size: 34)) + Text(String(score_1)).font(.custom("AcademyEngravedLETPlain", size: 34)) + Text(" - ").font(.custom("AcademyEngravedLETPlain", size: 34)) + Text(String(score_2)).font(.custom("AcademyEngravedLETPlain", size: 34)) + Text(")").font(.custom("AcademyEngravedLETPlain", size: 34))
                            
                            Text("Restart the game.")
                                .font(.custom("AcademyEngravedLETPlain", size: 34))
                        }
                        if score_2 == 3{
                            Text("Player 2 won (").font(.custom("AcademyEngravedLETPlain", size: 34)) + Text(String(score_1)).font(.custom("AcademyEngravedLETPlain", size: 34)) + Text(" - ").font(.custom("AcademyEngravedLETPlain", size: 34)) + Text(String(score_2)).font(.custom("AcademyEngravedLETPlain", size: 34)) + Text(")").font(.custom("AcademyEngravedLETPlain", size: 34))
                            
                            Text("Restart the game.")
                                .font(.custom("AcademyEngravedLETPlain", size: 34))
                        }
                    }
                    
                    Spacer()
                    
                    
                    HStack{
                        Spacer()
                        Button(action: {
                            // Action to perform when button is tapped
                            isActive = true
                            dragonIdx_1 = 0
                            dragonIdx_2 = 0
                            score_1 = 0
                            score_2 = 0
                        }) {
                            VStack{
                                Spacer()
                                Text("Restart")
                                    .font(.custom("AcademyEngravedLETPlain", size: 30))
                                    .foregroundColor(.primary)
                                Image("0_refresh_arrows")
                                    .resizable()
                                    .frame(width: 120, height: 120)
                                
                                
                                
                            }
                        }
                        Spacer()
                        Button(action: {
                            // Action to perform when button is tapped
                            randomIdx()
                            
                            if dragonIdx_1 < dragonIdx_2 {
                                score_1 = score_1 + 1
                            }
                            else if dragonIdx_1 > dragonIdx_2 {
                                score_2 = score_2 + 1
                            }
                        }) {
                            VStack{
                                Spacer()
                                Text("Fight")
                                    .font(.custom("AcademyEngravedLETPlain", size: 30))
                                    .foregroundColor(.primary)
                                Image("0_crossing-swords")
                                    .resizable()
                                    .frame(width: 120, height: 120)
                                
                            }
                        }
                        .disabled(score_1 == 3 || score_2 == 3)
                        Spacer()
                    }
                    .navigationDestination(isPresented: $isActive) {
                        GameView()
                    }
                    
                    Spacer()
                }
            }
            
            
            
            .tabItem {
                Image("fire_off")
                Text("Fight")
                
            }
        .navigationBarBackButtonHidden(true)
        }
        
    }
    func randomIdx() {
        dragonIdx_1 = 0
        dragonIdx_2 = 0
        while dragonIdx_1 == dragonIdx_2 {
            dragonIdx_1 = Int.random(in: 0...7)
            dragonIdx_2 = Int.random(in: 0...7)
        }
    }
}

#Preview {
    GameView()
}
