//
//  ScoreView.swift
//  Exercise4_Khan_Hasher
//
//  Created by Hasher Khan on 9/17/24.
//

import SwiftUI

struct ScoreView: View {
    @Environment(\.verticalSizeClass) var verticalSizeClass: UserInterfaceSizeClass?
    
    var body: some View {
        if verticalSizeClass == .regular{
            VStack {
                VStack{
                    Image("0_HOD_text")
                        .resizable()
                        .frame(width: 375, height: 55)
                    
                    Text("Player 1")
                        .font(.custom("AcademyEngravedLETPlain", size: 50))
                    
                    HStack{
                        Spacer()
                        Image("0_HOD_logo")
                            .resizable()
                            .frame(width: 110, height: 110)
                            .opacity(0.2)
                        Spacer()
                        Image("0_HOD_logo")
                            .resizable()
                            .frame(width: 110, height: 110)
                            .opacity(0.2)
                        Spacer()
                        Image("0_HOD_logo")
                            .resizable()
                            .frame(width: 110, height: 110)
                            .opacity(0.2)
                        Spacer()
                        
                    }
                }
                
                
                VStack{
                    Spacer()
                    Spacer()
                    
                    Text("Player 2")
                        .font(.custom("AcademyEngravedLETPlain", size: 50))
                    
                    
                    HStack{
                        Spacer()
                        Image("0_HOD_logo")
                            .resizable()
                            .frame(width: 110, height: 110)
                            .opacity(0.2)
                        Spacer()
                        Image("0_HOD_logo")
                            .resizable()
                            .frame(width: 110, height: 110)
                            .opacity(0.2)
                        Spacer()
                        Image("0_HOD_logo")
                            .resizable()
                            .frame(width: 110, height: 110)
                            .opacity(0.2)
                        Spacer()
                        
                    }
                    Spacer()
                    Spacer()
                    Spacer()
                    
                }
                
                .tabItem {
                    Image("score_off")
                    Text("Score")
                    
                }
                .tabItem {
                    Image("score_off")
                    Text("Score")}
            }
        }else if verticalSizeClass == .compact{
            HStack {
                VStack{
                    Image("0_HOD_text")
                        .resizable()
                        .frame(width: 375, height: 55)
                    
                    Text("Player 1")
                        .font(.custom("AcademyEngravedLETPlain", size: 50))
                    
                    HStack{
                        Spacer()
                        Image("0_HOD_logo")
                            .resizable()
                            .frame(width: 110, height: 110)
                            .opacity(0.2)
                        Spacer()
                        Image("0_HOD_logo")
                            .resizable()
                            .frame(width: 110, height: 110)
                            .opacity(0.2)
                        Spacer()
                        Image("0_HOD_logo")
                            .resizable()
                            .frame(width: 110, height: 110)
                            .opacity(0.2)
                        Spacer()
                        
                    }
                }
                
                
                VStack{
                    Spacer(minLength: 101)
                    Spacer()
                    
                    Text("Player 2")
                        .font(.custom("AcademyEngravedLETPlain", size: 50))
                    
                    
                    HStack{
                        Spacer()
                        Image("0_HOD_logo")
                            .resizable()
                            .frame(width: 110, height: 110)
                            .opacity(0.2)
                        Spacer()
                        Image("0_HOD_logo")
                            .resizable()
                            .frame(width: 110, height: 110)
                            .opacity(0.2)
                        Spacer()
                        Image("0_HOD_logo")
                            .resizable()
                            .frame(width: 110, height: 110)
                            .opacity(0.2)
                        Spacer()
                        
                    }
                    Spacer()
                   
                    
                }
                
                
                    
               
            }
            .tabItem {
                Image("score_off")
                Text("Score")}
            
        }
            
    }
        
}

#Preview {
    ScoreView()
}
